
const express = require('express');
const { db, init } = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();
init();

// Create event
router.post('/', auth, async (req, res) => {
  await db.read();

  const event = {
    id: Date.now(),
    ...req.body,
    createdBy: req.user.id,
    isDeleted: false
  };

  db.data.events.push(event);
  await db.write();

  res.json(event);
});

// Get events (publish filter)
router.get('/', async (req, res) => {
  await db.read();

  const now = new Date();

  const events = db.data.events.filter(e =>
    !e.isDeleted && new Date(e.publishAt) <= now
  );

  res.json(events);
});

// Delete event
router.delete('/:id', auth, async (req, res) => {
  await db.read();

  const event = db.data.events.find(e => e.id == req.params.id);
  if (!event) return res.status(404).json({ message: 'Not found' });

  event.isDeleted = true;

  await db.write();
  res.json({ message: 'Deleted' });
});

module.exports = router;
