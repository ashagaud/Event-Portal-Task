
const express = require('express');
const { db, init } = require('../db');
const auth = require('../middleware/auth');

const router = express.Router();
init();

router.post('/', auth, async (req, res) => {
  await db.read();

  const category = {
    id: Date.now(),
    name: req.body.name,
    parentId: req.body.parentId || null
  };

  db.data.categories.push(category);
  await db.write();

  res.json(category);
});

router.get('/', async (req, res) => {
  await db.read();
  res.json(db.data.categories);
});

module.exports = router;
