
const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { db, init } = require('../db');

const router = express.Router();
const SECRET = 'secret123';

init();

router.post('/register', async (req, res) => {
  await db.read();
  const { username, password } = req.body;

  const hash = await bcrypt.hash(password, 10);
  db.data.users.push({ id: Date.now(), username, password: hash });
  await db.write();

  res.json({ message: 'User created' });
});

router.post('/login', async (req, res) => {
  await db.read();
  const { username, password } = req.body;

  const user = db.data.users.find(u => u.username === username);
  if (!user) return res.status(400).json({ message: 'User not found' });

  const match = await bcrypt.compare(password, user.password);
  if (!match) return res.status(400).json({ message: 'Wrong password' });

  const token = jwt.sign({ id: user.id, username }, SECRET, { expiresIn: '1h' });

  res.json({ token });
});

module.exports = router;
