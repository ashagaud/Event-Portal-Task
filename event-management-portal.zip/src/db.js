
const { Low } = require('lowdb');
const { JSONFile } = require('lowdb/node');

const adapter = new JSONFile('db.json');
const db = new Low(adapter);

async function init() {
  await db.read();
  db.data ||= { users: [], events: [], categories: [] };
  await db.write();
}

module.exports = { db, init };
